package deliveryws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryWsApplication.class, args);
	}

}
