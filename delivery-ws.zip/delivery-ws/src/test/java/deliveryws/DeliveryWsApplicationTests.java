package deliveryws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
